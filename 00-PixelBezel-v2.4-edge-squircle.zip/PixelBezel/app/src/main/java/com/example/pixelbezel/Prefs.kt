package com.example.pixelbezel

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("bezel", Context.MODE_PRIVATE)
    private val defaults = mapOf("side" to 1, "y" to 30, "size" to 100, "idle" to 0)
    fun get(c: Context, k: String): Int = sp(c).getInt(k, defaults[k] ?: 0)
    fun set(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun side(c: Context) = get(c, "side")   // 0 = left, 1 = right
    fun yPct(c: Context) = get(c, "y")      // 10..90 percent of screen height
    fun size(c: Context) = get(c, "size")   // 70..150 percent
}

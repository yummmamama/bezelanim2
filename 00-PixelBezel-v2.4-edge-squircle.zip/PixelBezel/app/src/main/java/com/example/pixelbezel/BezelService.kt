package com.example.pixelbezel

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.roundToInt

class BezelService : AccessibilityService() {
    companion object { var instance: BezelService? = null }

    private val FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var view: BezelView
    private lateinit var lp: WindowManager.LayoutParams
    private var stream = AudioManager.STREAM_MUSIC
    private var holdDir = 0
    private var steps = 0
    private val h = Handler(Looper.getMainLooper())
    private val hide = Runnable { hideNow() }
    private val lock = Runnable { setTouchable(false) }
    private val repeat = object : Runnable {
        override fun run() {
            if (holdDir == 0 || steps++ > 120) return
            step(holdDir)
            h.postDelayed(this, 70)
        }
    }

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        view = BezelView(this)
        view.onGrab = { h.removeCallbacks(hide); h.removeCallbacks(lock) }
        view.onRelease = { h.postDelayed(hide, 1500) }
        view.onVolume = { f ->
            val max = audio.getStreamMaxVolume(stream)
            try { audio.setStreamVolume(stream, (f * max).roundToInt(), 0) } catch (_: SecurityException) {}
        }
        lp = WindowManager.LayoutParams(
            (120 * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (Prefs.side(this) == 1) Gravity.END else Gravity.START
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(view, lp)
    }

    private fun level(): Float {
        val max = audio.getStreamMaxVolume(stream)
        return if (max <= 0) 0f else audio.getStreamVolume(stream).toFloat() / max
    }

    private fun setTouchable(on: Boolean) {
        val f = if (on) FLAGS else FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val g = if (Prefs.side(this) == 1) Gravity.END else Gravity.START
        if (lp.flags != f || lp.gravity != g) {
            lp.flags = f; lp.gravity = g
            wm.updateViewLayout(view, lp)
        }
    }

    // Picks whichever volume the buttons should control right now.
    private fun pickStream(): Int = when {
        audio.mode == AudioManager.MODE_IN_CALL || audio.mode == AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        audio.mode == AudioManager.MODE_RINGTONE -> AudioManager.STREAM_RING
        audio.isMusicActive -> AudioManager.STREAM_MUSIC
        Prefs.get(this, "idle") == 1 -> AudioManager.STREAM_RING
        else -> AudioManager.STREAM_MUSIC
    }

    private fun present(pressed: Boolean) {
        view.side = Prefs.side(this)
        view.yPct = Prefs.yPct(this)
        view.scale = Prefs.size(this) / 100f
        view.target = level()
        h.removeCallbacks(hide); h.removeCallbacks(lock)
        view.open(pressed)          // animation starts first...
        setTouchable(true)          // ...then the window gets touch handling
    }

    private fun step(dir: Int) {
        try {
            audio.adjustStreamVolume(stream, if (dir > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        } catch (_: SecurityException) {}
        view.target = level()
        view.bubble.v += 20f
        view.kick()
    }

    private fun hideNow() {
        if (view.dragging) { h.postDelayed(hide, 600); return }
        view.close()
        h.postDelayed(lock, 700)
    }

    fun preview() {
        stream = pickStream()
        present(true)
        h.postDelayed(hide, 1500)
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode != KeyEvent.KEYCODE_VOLUME_UP && e.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val dir = if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount == 0) {
                stream = pickStream()
                present(true)
                step(dir)
                holdDir = dir; steps = 0
                h.removeCallbacks(repeat)
                h.postDelayed(repeat, 380)   // hold the button to keep going
            }
        } else if (e.action == KeyEvent.ACTION_UP) {
            holdDir = 0
            h.removeCallbacks(repeat)
            h.postDelayed(hide, 1200)
        }
        return true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        instance = null
        try { wm.removeView(view) } catch (_: Exception) {}
        super.onDestroy()
    }
}

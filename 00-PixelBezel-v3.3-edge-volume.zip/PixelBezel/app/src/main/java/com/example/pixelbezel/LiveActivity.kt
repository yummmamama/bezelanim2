package com.example.pixelbezel

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Drawable
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import java.util.concurrent.CopyOnWriteArrayList

enum class ActivityKind(val label: String, val priority: Int) {
    CALL("Call", 100), NAVIGATION("Navigation", 90), TIMER("Timer", 85),
    MEDIA("Now playing", 80), RECORDING("Recording", 70),
    WORKOUT("Workout", 65), PROGRESS("In progress", 55), ONGOING("Live activity", 40)
}

data class LiveAction(val title: String, val pendingIntent: PendingIntent)

data class LiveActivity(
    val key: String,
    val packageName: String,
    val appName: String,
    val kind: ActivityKind,
    val title: String,
    val text: String,
    val postedAt: Long,
    val whenMillis: Long,
    val chronometer: Boolean,
    val countDown: Boolean,
    val progress: Int,
    val progressMax: Int,
    val icon: Drawable?,
    val contentIntent: PendingIntent?,
    val actions: List<LiveAction>
)

/** In-process handoff from Android's notification listener to the accessibility overlay. */
object LiveActivityStore {
    private val entries = LinkedHashMap<String, LiveActivity>()
    @Volatile var observer: ((List<LiveActivity>) -> Unit)? = null

    @Synchronized fun snapshot(): List<LiveActivity> = entries.values
        .sortedWith(compareByDescending<LiveActivity> { it.kind.priority }.thenByDescending { it.postedAt })

    @Synchronized fun put(activity: LiveActivity) {
        entries[activity.key] = activity
        publish()
    }

    @Synchronized fun remove(key: String) {
        if (entries.remove(key) != null) publish()
    }

    @Synchronized fun replaceAll(activities: List<LiveActivity>) {
        entries.clear()
        activities.forEach { entries[it.key] = it }
        publish()
    }

    private fun publish() { observer?.invoke(snapshot()) }
}

class LiveActivityListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        val current = try { activeNotifications.orEmpty().mapNotNull { it.toLiveActivity(this) } }
        catch (_: Exception) { emptyList() }
        LiveActivityStore.replaceAll(current)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        sbn.toLiveActivity(this)?.let(LiveActivityStore::put) ?: LiveActivityStore.remove(sbn.key)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        LiveActivityStore.remove(sbn.key)
    }

    override fun onListenerDisconnected() {
        LiveActivityStore.replaceAll(emptyList())
        requestRebind(ComponentName(this, LiveActivityListener::class.java))
        super.onListenerDisconnected()
    }
}

fun notificationAccessEnabled(context: Context): Boolean = try {
    Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
        ?.split(':')?.any { it.equals(ComponentName(context, LiveActivityListener::class.java).flattenToString(), true) } == true
} catch (_: Exception) { false }

private fun StatusBarNotification.toLiveActivity(context: Context): LiveActivity? {
    if (packageName == context.packageName) return null
    val n = notification ?: return null
    val extras = n.extras ?: return null
    val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
    val body = (extras.getCharSequence(Notification.EXTRA_TEXT)
        ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString()?.trim().orEmpty()
    val category = n.category.orEmpty()
    val text = "$title $body $packageName".lowercase()
    val isMedia = category == Notification.CATEGORY_TRANSPORT || extras.containsKey("android.mediaSession")
    val progressMax = extras.getInt("android.progressMax", 0)
    val progress = extras.getInt("android.progress", 0)
    val hasProgress = progressMax > 0
    val hasChronometer = extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
    val ongoing = n.flags and Notification.FLAG_ONGOING_EVENT != 0
    val kind = when {
        category == Notification.CATEGORY_CALL -> ActivityKind.CALL
        category == Notification.CATEGORY_NAVIGATION -> ActivityKind.NAVIGATION
        isMedia -> ActivityKind.MEDIA
        category == Notification.CATEGORY_ALARM || category == Notification.CATEGORY_EVENT || hasChronometer -> ActivityKind.TIMER
        category == "workout" || listOf("workout", "running", "cycling", "exercise", "step count").any(text::contains) -> ActivityKind.WORKOUT
        listOf("screen recording", "recording screen", "voice recording", "recording audio", "hotspot", "flashlight", "torch active").any(text::contains) -> ActivityKind.RECORDING
        category == Notification.CATEGORY_PROGRESS || hasProgress -> ActivityKind.PROGRESS
        ongoing && (category == Notification.CATEGORY_SERVICE || category == Notification.CATEGORY_STATUS ||
            listOf("delivery", "your ride", "trip in progress", "uploading", "downloading", "sharing location", "stopwatch").any(text::contains)) -> ActivityKind.ONGOING
        else -> return null
    }
    if (!ongoing && kind !in setOf(ActivityKind.CALL, ActivityKind.MEDIA)) return null

    val appName = try { context.packageManager.getApplicationLabel(context.packageManager.getApplicationInfo(packageName, 0)).toString() }
        catch (_: Exception) { packageName.substringAfterLast('.') }
    val appIcon = try { context.packageManager.getApplicationIcon(packageName) } catch (_: Exception) { null }
    val actions = n.actions.orEmpty().take(3).mapNotNull { action ->
        val label = action.title?.toString()?.trim().orEmpty()
        val pendingIntent = action.actionIntent
        if (label.isEmpty() || pendingIntent == null) null else LiveAction(label, pendingIntent)
    }
    return LiveActivity(
        key = key, packageName = packageName, appName = appName,
        kind = kind, title = title.ifEmpty { appName }, text = body,
        postedAt = postTime, whenMillis = n.`when`, chronometer = hasChronometer,
        countDown = extras.getBoolean("android.chronometerCountDown", false),
        progress = progress, progressMax = progressMax, icon = appIcon,
        contentIntent = n.contentIntent, actions = actions
    )
}

package com.example.pixelbezel

import android.app.Activity
import android.content.pm.PackageManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(22), px(48), px(22), px(24))
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 15f; setPadding(0, px(22), 0, px(4)) }

        root.addView(TextView(this).apply { text = "Pixel Island"; textSize = 28f })
        status = TextView(this).apply { textSize = 14f; setPadding(0, px(8), 0, px(8)) }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Open accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Enable live-activity access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        root.addView(label("Live activities use notification access to show active calls, media, timers, navigation, and supported ongoing app notifications. You can turn this access off anytime in Android settings."))

        fun slider(name: String, key: String, lo: Int, hi: Int) {
            val tv = label("$name: ${Prefs.get(this, key)}")
            val sb = SeekBar(this).apply {
                this.max = hi - lo
                progress = Prefs.get(this@MainActivity, key) - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                        Prefs.set(this@MainActivity, key, p + lo)
                        tv.text = "$name: ${p + lo}"
                        if (fromUser) BezelService.instance?.preview()
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            }
            root.addView(tv); root.addView(sb)
        }

        root.addView(label("Side of screen"))
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        rg.addView(RadioButton(this).apply { text = "Left  "; id = 1 })
        rg.addView(RadioButton(this).apply { text = "Right"; id = 2 })
        rg.check(if (Prefs.side(this) == 0) 1 else 2)
        rg.setOnCheckedChangeListener { _, id ->
            Prefs.set(this, "side", if (id == 1) 0 else 1)
            BezelService.instance?.preview()
        }
        root.addView(rg)

        root.addView(label("When nothing is playing, volume keys control"))
        val ig = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        ig.addView(RadioButton(this).apply { text = "Media  "; id = 11 })
        ig.addView(RadioButton(this).apply { text = "Ringer"; id = 12 })
        ig.check(if (Prefs.get(this, "idle") == 1) 12 else 11)
        ig.setOnCheckedChangeListener { _, id -> Prefs.set(this, "idle", if (id == 12) 1 else 0) }
        root.addView(ig)

        slider("Vertical position (% from top)", "y", 10, 90)
        slider("Size (%)", "size", 70, 150)

        root.addView(Button(this).apply {
            text = "Preview"
            setOnClickListener { BezelService.instance?.preview() }
        })
        root.addView(Button(this).apply {
            text = "Preview flashlight island"
            setOnClickListener { openFlashlightIsland() }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun openFlashlightIsland() {
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.CAMERA), 41)
            return
        }
        val service = BezelService.instance
        if (service == null) {
            status.text = "Turn on Pixel Bezel in accessibility settings, then preview the flashlight island."
        } else {
            service.previewFlashlight()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            openFlashlightIsland()
        } else if (requestCode == 41) {
            status.text = "Camera access is needed to control the flashlight. You can allow it in app settings."
        }
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        val liveEnabled = notificationAccessEnabled(this)
        status.text = "Overlay: ${if (enabled) "On" else "Off"} · Live activities: ${if (liveEnabled) "On" else "Off"}\n" +
            if (enabled) "Press a volume key or preview the flashlight card."
            else "Turn on the accessibility service to display the island."
    }
}

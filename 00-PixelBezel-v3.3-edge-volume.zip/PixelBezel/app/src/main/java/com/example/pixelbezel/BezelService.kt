package com.example.pixelbezel

import android.accessibilityservice.AccessibilityService
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.roundToInt

class BezelService : AccessibilityService() {
    companion object { var instance: BezelService? = null }

    private val FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var view: BezelView
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var flashlightView: FlashlightIslandView
    private lateinit var flashlightLp: WindowManager.LayoutParams
    private lateinit var liveActivityView: LiveActivityView
    private lateinit var liveActivityLp: WindowManager.LayoutParams
    private lateinit var cameraManager: CameraManager
    private var flashCameraId: String? = null
    private var torchMaxStrength = 1
    private var torchLevel = 1f
    private var torchOn = false
    private var flashlightAutoShown = false
    private var flashlightVisible = false
    private var stream = AudioManager.STREAM_MUSIC
    private var holdDir = 0
    private var steps = 0
    private val h = Handler(Looper.getMainLooper())
    private val hide = Runnable { hideNow() }
    private val lock = Runnable { setTouchable(false) }
    private val hideFlashlight = Runnable {
        flashlightVisible = false
        flashlightView.dismiss()
        flashlightLp.flags = FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(flashlightView, flashlightLp) } catch (_: Exception) {}
        flashlightView.postDelayed({ if (!flashlightVisible) liveActivityView.visibility = android.view.View.VISIBLE }, 240)
    }
    private val repeat = object : Runnable {
        override fun run() {
            if (holdDir == 0 || steps++ > 120) return
            step(holdDir)
            h.postDelayed(this, 70)
        }
    }

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId != flashCameraId) return
            torchOn = enabled
            flashlightView.setTorchState(torchOn, torchLevel, torchMaxStrength > 1)
            if (enabled) {
                flashlightAutoShown = true
                h.removeCallbacks(hideFlashlight)
                showFlashlightOverlay()
            } else if (flashlightAutoShown) {
                flashlightAutoShown = false
                h.removeCallbacks(hideFlashlight)
                hideFlashlight.run()
            }
        }

        override fun onTorchModeUnavailable(cameraId: String) {
            if (cameraId != flashCameraId) return
            torchOn = false
            flashlightView.setTorchState(false, torchLevel, torchMaxStrength > 1)
            if (flashlightAutoShown) {
                flashlightAutoShown = false
                h.removeCallbacks(hideFlashlight)
                hideFlashlight.run()
            }
        }
    }

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        findFlashCamera()
        view = BezelView(this)
        view.onGrab = { h.removeCallbacks(hide); h.removeCallbacks(lock) }
        view.onRelease = { h.postDelayed(hide, 1500) }
        view.onVolume = { f ->
            val max = audio.getStreamMaxVolume(stream)
            try { audio.setStreamVolume(stream, (f * max).roundToInt(), 0) } catch (_: SecurityException) {}
        }
        lp = WindowManager.LayoutParams(
            (120 * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (Prefs.side(this) == 1) Gravity.END else Gravity.START
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(view, lp)

        flashlightView = FlashlightIslandView(this)
        flashlightView.onToggleTorch = { toggleTorch() }
        flashlightView.onBrightnessChanged = { setTorchLevel(it) }
        flashlightLp = WindowManager.LayoutParams(
            (340 * resources.displayMetrics.density).toInt(),
            (434 * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        flashlightLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        flashlightLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(flashlightView, flashlightLp)

        liveActivityView = LiveActivityView(this)
        liveActivityView.setActivities(LiveActivityStore.snapshot())
        val liveFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        liveActivityLp = WindowManager.LayoutParams(
            (360 * resources.displayMetrics.density).toInt(),
            (180 * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            liveFlags,
            PixelFormat.TRANSLUCENT
        )
        liveActivityLp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        liveActivityLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(liveActivityView, liveActivityLp)
        LiveActivityStore.observer = { activities ->
            liveActivityView.setActivities(activities)
            val flags = (liveFlags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()) or
                (if (activities.isEmpty()) WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else 0)
            if (liveActivityLp.flags != flags) {
                liveActivityLp.flags = flags
                try { wm.updateViewLayout(liveActivityView, liveActivityLp) } catch (_: Exception) {}
            }
        }
        cameraManager.registerTorchCallback(torchCallback, h)
    }

    private fun level(): Float {
        val max = audio.getStreamMaxVolume(stream)
        return if (max <= 0) 0f else audio.getStreamVolume(stream).toFloat() / max
    }

    private fun setTouchable(on: Boolean) {
        val f = if (on) FLAGS else FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val g = if (Prefs.side(this) == 1) Gravity.END else Gravity.START
        if (lp.flags != f || lp.gravity != g) {
            lp.flags = f; lp.gravity = g
            wm.updateViewLayout(view, lp)
        }
    }

    // Picks whichever volume the buttons should control right now.
    private fun pickStream(): Int = when {
        audio.mode == AudioManager.MODE_IN_CALL || audio.mode == AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        audio.mode == AudioManager.MODE_RINGTONE -> AudioManager.STREAM_RING
        audio.isMusicActive -> AudioManager.STREAM_MUSIC
        Prefs.get(this, "idle") == 1 -> AudioManager.STREAM_RING
        else -> AudioManager.STREAM_MUSIC
    }

    private fun present(pressed: Boolean) {
        view.side = Prefs.side(this)
        view.yPct = Prefs.yPct(this)
        view.scale = Prefs.size(this) / 100f
        view.target = level()
        h.removeCallbacks(hide); h.removeCallbacks(lock)
        view.open(pressed)          // animation starts first...
        setTouchable(true)          // ...then the window gets touch handling
    }

    private fun step(dir: Int) {
        try {
            audio.adjustStreamVolume(stream, if (dir > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        } catch (_: SecurityException) {}
        view.target = level()
        view.bubble.v += 20f
        view.kick()
    }

    private fun hideNow() {
        if (view.dragging) { h.postDelayed(hide, 600); return }
        view.close()
        h.postDelayed(lock, 700)
    }

    fun preview() {
        stream = pickStream()
        present(true)
        h.postDelayed(hide, 1500)
    }

    fun previewFlashlight() {
        h.removeCallbacks(hide)
        h.removeCallbacks(lock)
        h.removeCallbacks(hideFlashlight)
        flashlightAutoShown = torchOn
        showFlashlightOverlay()
        if (!torchOn) h.postDelayed(hideFlashlight, 8000)
    }

    private fun showFlashlightOverlay() {
        flashlightVisible = true
        liveActivityView.visibility = android.view.View.INVISIBLE
        flashlightView.show(torchOn, torchLevel, torchMaxStrength > 1)
        flashlightLp.flags = FLAGS
        try { wm.updateViewLayout(flashlightView, flashlightLp) } catch (_: Exception) {}
    }

    private fun findFlashCamera() {
        flashCameraId = try {
            val cameras = cameraManager.cameraIdList.filter { id ->
                cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            cameras.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameras.firstOrNull()
        } catch (_: Exception) { null }
        torchMaxStrength = if (Build.VERSION.SDK_INT >= 33 && flashCameraId != null) {
            try {
                cameraManager.getCameraCharacteristics(flashCameraId!!)
                    .get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
            } catch (_: Exception) { 1 }
        } else 1
    }

    private fun toggleTorch() {
        val id = flashCameraId ?: return
        try {
            if (torchOn) {
                cameraManager.setTorchMode(id, false)
                torchOn = false
            } else {
                setTorchLevel(torchLevel)
                torchOn = true
            }
            flashlightView.setTorchState(torchOn, torchLevel, torchMaxStrength > 1)
        } catch (_: CameraAccessException) {
            flashlightView.setTorchState(false, torchLevel, torchMaxStrength > 1)
        } catch (_: SecurityException) {
            flashlightView.setTorchState(false, torchLevel, torchMaxStrength > 1)
        }
    }

    private fun setTorchLevel(value: Float) {
        val id = flashCameraId ?: return
        torchLevel = value.coerceIn(0.08f, 1f)
        try {
            if (torchMaxStrength > 1 && Build.VERSION.SDK_INT >= 33) {
                val strength = 1 + ((torchMaxStrength - 1) * torchLevel).roundToInt()
                cameraManager.turnOnTorchWithStrengthLevel(id, strength)
                torchOn = true
            } else if (!torchOn) {
                cameraManager.setTorchMode(id, true)
                torchOn = true
            }
            flashlightView.setTorchState(torchOn, torchLevel, torchMaxStrength > 1)
        } catch (_: CameraAccessException) {
            flashlightView.setTorchState(torchOn, torchLevel, torchMaxStrength > 1)
        } catch (_: SecurityException) {
            flashlightView.setTorchState(torchOn, torchLevel, torchMaxStrength > 1)
        }
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode != KeyEvent.KEYCODE_VOLUME_UP && e.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        val dir = if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount == 0) {
                stream = pickStream()
                present(true)
                step(dir)
                holdDir = dir; steps = 0
                h.removeCallbacks(repeat)
                h.postDelayed(repeat, 380)   // hold the button to keep going
            }
        } else if (e.action == KeyEvent.ACTION_UP) {
            holdDir = 0
            h.removeCallbacks(repeat)
            h.postDelayed(hide, 1200)
        }
        return true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        instance = null
        h.removeCallbacks(hideFlashlight)
        h.removeCallbacks(hide)
        h.removeCallbacks(lock)
        h.removeCallbacks(repeat)
        try { cameraManager.unregisterTorchCallback(torchCallback) } catch (_: Exception) {}
        try { wm.removeView(view) } catch (_: Exception) {}
        try { wm.removeView(flashlightView) } catch (_: Exception) {}
        LiveActivityStore.observer = null
        try { wm.removeView(liveActivityView) } catch (_: Exception) {}
        super.onDestroy()
    }
}

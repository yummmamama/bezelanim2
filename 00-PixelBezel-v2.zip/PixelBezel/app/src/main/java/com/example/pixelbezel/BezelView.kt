package com.example.pixelbezel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class Spring(var x: Float = 0f, var t: Float = 0f, var k: Float = 420f, var c: Float = 19f, val eps: Float = 0.15f) {
    var v = 0f
    fun step(dt: Float) { v += (-k * (x - t) - c * v) * dt; x += v * dt }
    fun atRest() = abs(v) < eps * 4f && abs(x - t) < eps
}

/** The bezel itself bulges out into a bubble, and the volume slider lives inside that bubble. */
class BezelView(ctx: Context) : View(ctx) {
    private val dp = resources.displayMetrics.density
    val bubble = Spring()                                  // bubble depth in dp
    val big = Spring(k = 380f, c = 22f, eps = 0.003f)      // 0 = thin slider, 1 = thick slider
    val stretch = Spring(k = 260f, c = 14f, eps = 0.003f)  // rubber-band overdrag
    var side = 1
    var yPct = 30
    var scale = 1f
    var target = 0.5f
    var dragging = false
        private set
    var onGrab: (() -> Unit)? = null
    var onVolume: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null

    private var disp = 0.5f
    private var last = 0L
    private val hit = RectF()
    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x22FFFFFF; strokeWidth = 1f }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; strokeCap = Paint.Cap.ROUND }
    private val iconFill = Paint(Paint.ANTI_ALIAS_FLAG)

    fun kick() = postInvalidateOnAnimation()

    /** Pops the bubble out right now. */
    fun open(pressed: Boolean) {
        bubble.t = 40f + 18f * big.t
        if (pressed) { bubble.k = 560f; bubble.c = 22f; bubble.v += 150f }
        kick()
    }

    /** Pulls the bubble back into the bezel. */
    fun close() {
        big.t = 0f; bubble.t = 0f; bubble.k = 300f; bubble.c = 26f
        kick()
    }

    private fun cyOf(h: Float): Float {
        val m = 112f * dp * scale
        return (h * yPct / 100f).coerceIn(m, max(m, h - m))
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.032f, (now - last) / 1e9f)
        last = now
        bubble.step(dt); big.step(dt)
        if (!dragging) stretch.step(dt)
        disp = if (dragging) target else disp + (target - disp) * 0.35f
        val w = width.toFloat()
        val h = height.toFloat()
        drawBubble(c, w, cyOf(h))
        val busy = dragging || !bubble.atRest() || !big.atRest() || !stretch.atRest() || abs(disp - target) > 0.002f
        if (busy) postInvalidateOnAnimation() else last = 0L
    }

    private fun drawBubble(c: Canvas, w: Float, cy: Float) {
        val s = dp * scale
        val b = big.x.coerceIn(0f, 1f)
        val d = bubble.x * s
        if (d < 1f) { hit.setEmpty(); return }
        val hh = (92f + 10f * b) * s
        fun X(v: Float) = if (side == 1) v else w - v

        val bp = Path()
        bp.moveTo(X(w + 6f), cy - hh); bp.lineTo(X(w), cy - hh)
        bp.cubicTo(X(w), cy - hh * 0.85f, X(w - d), cy - hh * 0.65f, X(w - d), cy - hh * 0.5f)
        bp.lineTo(X(w - d), cy + hh * 0.5f)
        bp.cubicTo(X(w - d), cy + hh * 0.65f, X(w), cy + hh * 0.85f, X(w), cy + hh)
        bp.lineTo(X(w + 6f), cy + hh); bp.close()
        c.drawPath(bp, black); c.drawPath(bp, rim)
        hit.set(min(X(w - d), X(w)), cy - hh, max(X(w - d), X(w)), cy + hh)

        val appear = ((d / s - 14f) / 26f).coerceIn(0f, 1f)
        if (appear <= 0f) return
        val sw = (14f + 20f * b) * s
        val sh = (120f + 16f * b) * s
        val cx = X(w - d / 2f)
        val r = RectF(cx - sw / 2f, cy - sh / 2f, cx + sw / 2f, cy + sh / 2f)
        val st = stretch.x
        val pivotY = if (st >= 0f) r.bottom else r.top

        c.save()
        c.clipPath(bp)
        c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (appear * 255).toInt())
        c.scale(1f - abs(st) * 1.2f, 1f + abs(st), r.centerX(), pivotY)
        c.clipPath(Path().apply { addRoundRect(r, sw / 2f, sw / 2f, Path.Direction.CW) })
        c.drawRect(r, track)
        val fh = sh * disp.coerceIn(0f, 1f)
        c.drawRect(r.left, r.bottom - fh, r.right, r.bottom, white)
        if (b > 0.3f) drawIcon(c, r, fh, b)
        c.restore()
        c.restore()
    }

    private fun drawIcon(c: Canvas, r: RectF, fh: Float, b: Float) {
        val s = dp * scale
        val col = if (fh > 32f * s) 0xCC1A1A1E.toInt() else Color.WHITE
        icon.color = col; iconFill.color = col
        icon.alpha = (b * 255).toInt(); iconFill.alpha = (b * 255).toInt()
        c.save()
        c.translate(r.centerX() - 9f * s, r.bottom - 29f * s)
        c.scale(18f * s / 24f, 18f * s / 24f)
        val p = Path()
        p.moveTo(3f, 9f); p.lineTo(3f, 15f); p.lineTo(7f, 15f); p.lineTo(12f, 19f); p.lineTo(12f, 5f); p.lineTo(7f, 9f); p.close()
        c.drawPath(p, iconFill)
        if (disp > 0f) c.drawArc(RectF(7.5f, 7.5f, 16.5f, 16.5f), -45f, 90f, false, icon)
        if (disp > 0.55f) c.drawArc(RectF(4f, 4f, 20f, 20f), -45f, 90f, false, icon)
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val slop = 12f * dp
                val r = RectF(hit).apply { inset(-slop, -slop) }
                if (hit.width() <= 0f || !r.contains(e.x, e.y)) return false
                dragging = true
                big.t = 1f; bubble.t = 58f; bubble.k = 380f; bubble.c = 20f
                onGrab?.invoke(); drag(e.y); kick()
                return true
            }
            MotionEvent.ACTION_MOVE -> if (dragging) { drag(e.y); kick() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false; stretch.t = 0f; onRelease?.invoke(); kick()
            }
        }
        return dragging
    }

    private fun drag(y: Float) {
        val sliderH = 136f * dp * scale
        val top = cyOf(height.toFloat()) - sliderH / 2f
        val rel = (y - top) / sliderH
        target = (1f - rel).coerceIn(0f, 1f)
        disp = target
        onVolume?.invoke(target)
        val over = (if (rel < 0f) -rel else if (rel > 1f) rel - 1f else 0f) * sliderH / dp
        val e = if (over > 0f) min(0.3f, sqrt(over) / 156f * 2.2f) else 0f
        stretch.x = if (rel < 0f) e else -e
        stretch.v = 0f
    }
}

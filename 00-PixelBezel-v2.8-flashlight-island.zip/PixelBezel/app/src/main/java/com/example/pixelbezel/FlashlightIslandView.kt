package com.example.pixelbezel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/** Expanded flashlight card modeled around the Pixel's centered camera cutout. */
class FlashlightIslandView(context: Context) : View(context) {
    private val dp = resources.displayMetrics.density
    private val reveal = Spring(k = 340f, c = 31f, eps = 0.004f)
    private val beamMotion = Spring(k = 230f, c = 24f, eps = 0.008f)
    private var lastFrame = 0L
    private var expanded = false
    private var torchOn = false
    private var level = 1f
    private var strengthSupported = false
    private var draggingArc = false
    private var tappedLamp = false
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var card = RectF()
    private var arc = RectF()
    var onToggleTorch: (() -> Unit)? = null
    var onBrightnessChanged: ((Float) -> Unit)? = null

    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF050507.toInt() }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * dp
        color = 0xFF17171C.toInt()
    }
    private val arcTrack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * dp
        strokeCap = Paint.Cap.ROUND
        color = 0xFF45454D.toInt()
    }
    private val arcValue = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * dp
        strokeCap = Paint.Cap.ROUND
        color = 0xFFE9E9F2.toInt()
    }
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val lamp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val beam = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)

    fun show(isOn: Boolean, value: Float, supportsStrength: Boolean) {
        expanded = true
        reveal.t = 1f
        setTorchState(isOn, value, supportsStrength)
        postInvalidateOnAnimation()
    }

    fun dismiss() {
        expanded = false
        reveal.t = 0f
        postInvalidateOnAnimation()
    }

    fun setTorchState(isOn: Boolean, value: Float, supportsStrength: Boolean) {
        torchOn = isOn
        level = value.coerceIn(0.08f, 1f)
        strengthSupported = supportsStrength
        beamMotion.t = if (isOn) level else 0f
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        val dt = if (lastFrame == 0L) 0.016f else ((now - lastFrame) / 1e9f).coerceIn(0.001f, 0.032f)
        lastFrame = now
        reveal.step(dt)
        beamMotion.step(dt)
        val amount = reveal.x.coerceIn(0f, 1f)
        if (amount > 0.005f) drawCard(canvas, amount)
        if (expanded || !reveal.atRest() || !beamMotion.atRest()) postInvalidateOnAnimation() else lastFrame = 0L
    }

    private fun drawCard(c: Canvas, amount: Float) {
        val maxW = min(width - 14f * dp, 332f * dp)
        val maxH = min(height - 14f * dp, 418f * dp)
        val w = maxW * (0.90f + amount * 0.10f)
        val h = maxH * (0.84f + amount * 0.16f)
        val cx = width / 2f
        val top = 8f * dp + (maxH - h) * 0.08f
        card.set(cx - w / 2f, top, cx + w / 2f, top + h)

        c.save()
        c.scale(0.92f + amount * 0.08f, 0.92f + amount * 0.08f, cx, card.centerY())
        panel.alpha = (255f * amount).toInt()
        edge.alpha = (210f * amount).toInt()
        c.drawRoundRect(card, 62f * dp, 62f * dp, panel)
        c.drawRoundRect(card, 62f * dp, 62f * dp, edge)

        arc.set(card.left + 40f * dp, card.top + 92f * dp, card.right - 40f * dp, card.top + 198f * dp)
        drawBrightnessArc(c, amount)
        drawFlashlight(c, amount)
        c.restore()
    }

    private fun drawBrightnessArc(c: Canvas, alpha: Float) {
        val shownLevel = if (strengthSupported) level else if (torchOn) 1f else 0.08f
        val arcBox = RectF(arc)
        arcTrack.alpha = (205f * alpha).toInt()
        arcValue.alpha = (235f * alpha).toInt()
        c.drawArc(arcBox, 205f, 130f, false, arcTrack)
        c.drawArc(arcBox, 205f, 130f * shownLevel, false, arcValue)

        val angle = Math.toRadians((205f + 130f * shownLevel).toDouble())
        val rx = arcBox.width() / 2f
        val ry = arcBox.height() / 2f
        val x = arcBox.centerX() + rx * kotlin.math.cos(angle).toFloat()
        val y = arcBox.centerY() + ry * kotlin.math.sin(angle).toFloat()
        knob.alpha = (245f * alpha).toInt()
        c.drawCircle(x, y, 5f * dp, knob)

        val sunX = arcBox.right + 12f * dp
        val sunY = arcBox.centerY() + 6f * dp
        arcValue.alpha = (190f * alpha).toInt()
        c.drawCircle(sunX, sunY, 5f * dp, arcTrack)
        c.drawCircle(sunX, sunY, 3f * dp, arcValue)
        for (i in 0..7) {
            val a = Math.toRadians(i * 45.0)
            val x1 = sunX + kotlin.math.cos(a).toFloat() * 10f * dp
            val y1 = sunY + kotlin.math.sin(a).toFloat() * 10f * dp
            val x2 = sunX + kotlin.math.cos(a).toFloat() * 13f * dp
            val y2 = sunY + kotlin.math.sin(a).toFloat() * 13f * dp
            c.drawLine(x1, y1, x2, y2, arcTrack)
        }
    }

    private fun drawFlashlight(c: Canvas, alpha: Float) {
        val centerX = card.centerX()
        val lampY = card.top + card.height() * 0.72f
        val lampWidth = 29f * dp
        val lampHeight = 94f * dp
        val bright = beamMotion.x.coerceIn(0f, 1f)
        val beamTop = lampY - lampHeight - 40f * dp
        val beamBottom = lampY - 4f * dp
        val beamPath = Path().apply {
            moveTo(centerX - lampWidth * 0.34f, beamBottom)
            lineTo(centerX - 94f * dp, beamTop)
            quadTo(centerX, beamTop - 20f * dp, centerX + 94f * dp, beamTop)
            lineTo(centerX + lampWidth * 0.34f, beamBottom)
            close()
        }
        val beamAlpha = ((24f + 188f * bright) * alpha).toInt().coerceIn(0, 210)
        beam.shader = LinearGradient(
            centerX, beamBottom, centerX, beamTop,
            intArrayOf(Color.argb(beamAlpha, 255, 255, 255), Color.argb((beamAlpha * 0.34f).toInt(), 201, 217, 255), Color.TRANSPARENT),
            floatArrayOf(0f, 0.58f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(beamPath, beam)

        if (bright > 0.01f) {
            glow.shader = RadialGradient(centerX, beamTop + 28f * dp, 74f * dp,
                intArrayOf(Color.argb((105f * bright * alpha).toInt(), 226, 233, 255), Color.TRANSPARENT),
                null, Shader.TileMode.CLAMP)
            c.drawCircle(centerX, beamTop + 28f * dp, 74f * dp, glow)
        }

        val body = RectF(centerX - lampWidth / 2f, lampY - lampHeight * 0.52f, centerX + lampWidth / 2f, lampY + lampHeight / 2f)
        val head = RectF(centerX - lampWidth * 0.70f, lampY - lampHeight * 0.72f, centerX + lampWidth * 0.70f, lampY - lampHeight * 0.48f)
        lamp.alpha = (if (torchOn) 255f else 182f).times(alpha).toInt()
        c.drawRoundRect(head, 6f * dp, 6f * dp, lamp)
        c.drawRect(centerX - lampWidth * 0.70f, head.bottom + 4f * dp, centerX + lampWidth * 0.70f, head.bottom + 8f * dp, panel)
        c.drawRoundRect(body, 8f * dp, 8f * dp, lamp)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!card.contains(event.x, event.y)) return false
                touchStartX = event.x
                touchStartY = event.y
                val hit = RectF(arc).apply { inset(-22f * dp, -18f * dp) }
                draggingArc = strengthSupported && hit.contains(event.x, event.y)
                tappedLamp = !draggingArc && event.y > card.top + card.height() * 0.56f
                parent?.requestDisallowInterceptTouchEvent(true)
                if (draggingArc) updateLevel(event.x)
                return true
            }
            MotionEvent.ACTION_MOVE -> if (draggingArc) {
                updateLevel(event.x)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (tappedLamp && kotlin.math.hypot(event.x - touchStartX, event.y - touchStartY) < 24f * dp) onToggleTorch?.invoke()
                draggingArc = false
                tappedLamp = false
                performClick()
                return true
            }
        }
        return true
    }

    private fun updateLevel(x: Float) {
        val fraction = ((x - arc.left) / arc.width()).coerceIn(0.08f, 1f)
        level = fraction
        onBrightnessChanged?.invoke(fraction)
        invalidate()
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

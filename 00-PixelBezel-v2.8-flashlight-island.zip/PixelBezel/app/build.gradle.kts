plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.pixelbezel"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.pixelbezel"
        minSdk = 28
        targetSdk = 34
        versionCode = 10
        versionName = "2.8"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

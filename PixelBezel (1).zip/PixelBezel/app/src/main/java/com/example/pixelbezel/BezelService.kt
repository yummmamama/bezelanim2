package com.example.pixelbezel

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.roundToInt

class BezelService : AccessibilityService() {
    companion object { var instance: BezelService? = null }

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var view: BezelView
    private var stream = AudioManager.STREAM_MUSIC
    private val h = Handler(Looper.getMainLooper())
    private val hide = Runnable { hideNow() }
    private val gone = Runnable { if (view.show.t == 0f) view.visibility = View.GONE }

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        view = BezelView(this)
        view.visibility = View.GONE
        view.onGrab = { h.removeCallbacks(hide) }
        view.onRelease = { h.postDelayed(hide, 1500) }
        view.onVolume = { f ->
            val max = audio.getStreamMaxVolume(stream)
            try { audio.setStreamVolume(stream, (f * max).roundToInt(), 0) } catch (_: SecurityException) {}
        }
        wm.addView(view, params())
    }

    private fun params(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            (120 * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (Prefs.side(this) == 1) Gravity.END else Gravity.START
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return lp
    }

    private fun present(pressed: Boolean) {
        view.side = Prefs.side(this)
        view.yPct = Prefs.yPct(this)
        view.scale = Prefs.size(this) / 100f
        wm.updateViewLayout(view, params())
        val max = audio.getStreamMaxVolume(stream)
        view.target = audio.getStreamVolume(stream).toFloat() / max
        h.removeCallbacks(hide); h.removeCallbacks(gone)
        view.visibility = View.VISIBLE
        view.show.t = 1f
        if (pressed) {
            view.bulge.t = 16f; view.bulge.k = 420f; view.bulge.c = 19f; view.bulge.v += 60f
        }
        view.kick()
    }

    private fun release() {
        view.bulge.t = 0f; view.bulge.k = 240f; view.bulge.c = 17f
        view.kick()
        h.postDelayed(hide, 1100)
    }

    private fun hideNow() {
        if (view.dragging) { h.postDelayed(hide, 600); return }
        view.show.t = 0f; view.big.t = 0f
        view.kick()
        h.postDelayed(gone, 700)
    }

    // Picks whichever volume the buttons should control right now.
    private fun pickStream(): Int = when {
        audio.mode == AudioManager.MODE_IN_CALL || audio.mode == AudioManager.MODE_IN_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        audio.mode == AudioManager.MODE_RINGTONE -> AudioManager.STREAM_RING
        audio.isMusicActive -> AudioManager.STREAM_MUSIC
        Prefs.get(this, "idle") == 1 -> AudioManager.STREAM_RING
        else -> AudioManager.STREAM_MUSIC
    }

    fun preview() {
        stream = pickStream()
        present(true)
        h.postDelayed({ release() }, 450)
    }

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode != KeyEvent.KEYCODE_VOLUME_UP && e.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount == 0) stream = pickStream()
            try {
                audio.adjustStreamVolume(
                    stream,
                    if (e.keyCode == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    0
                )
            } catch (_: SecurityException) {}
            present(e.repeatCount == 0)
        } else if (e.action == KeyEvent.ACTION_UP) {
            release()
        }
        return true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        instance = null
        try { wm.removeView(view) } catch (_: Exception) {}
        super.onDestroy()
    }
}

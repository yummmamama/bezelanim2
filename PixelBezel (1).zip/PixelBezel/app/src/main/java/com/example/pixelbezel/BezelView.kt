package com.example.pixelbezel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

class Spring(var x: Float = 0f, var t: Float = 0f, var k: Float = 420f, var c: Float = 19f, val eps: Float = 0.15f) {
    var v = 0f
    fun step(dt: Float) { v += (-k * (x - t) - c * v) * dt; x += v * dt }
    fun atRest() = abs(v) < eps * 4f && abs(x - t) < eps
}

class BezelView(ctx: Context) : View(ctx) {
    private val dp = resources.displayMetrics.density
    val bulge = Spring()                                   // depth in dp
    val big = Spring(k = 380f, c = 22f, eps = 0.003f)      // 0 thin pill .. 1 thick pill
    val show = Spring(k = 300f, c = 24f, eps = 0.003f)     // pill entrance
    val stretch = Spring(k = 260f, c = 14f, eps = 0.003f)  // rubber-band overdrag
    var side = 1
    var yPct = 30
    var scale = 1f
    var target = 0.5f
    var dragging = false
        private set
    var onGrab: (() -> Unit)? = null
    var onVolume: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null

    private var disp = 0.5f
    private var last = 0L
    private val pill = RectF()
    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x22FFFFFF; strokeWidth = 1f }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66303036 }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; strokeCap = Paint.Cap.ROUND }
    private val iconFill = Paint(Paint.ANTI_ALIAS_FLAG)

    fun kick() = postInvalidateOnAnimation()

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.032f, (now - last) / 1e9f)
        last = now
        bulge.step(dt); big.step(dt); show.step(dt)
        if (!dragging) stretch.step(dt)
        disp = if (dragging) target else disp + (target - disp) * 0.3f
        val w = width.toFloat()
        val h = height.toFloat()
        val cy = h * yPct / 100f
        drawBulge(c, w, cy)
        drawPill(c, w, h, cy)
        val busy = dragging || !bulge.atRest() || !big.atRest() || !show.atRest() ||
            !stretch.atRest() || abs(disp - target) > 0.002f
        if (busy) postInvalidateOnAnimation() else last = 0L
    }

    private fun drawBulge(c: Canvas, w: Float, cy: Float) {
        val d = bulge.x * dp * scale
        if (d < 0.3f) return
        val hh = 46f * dp * scale
        val a = hh * 0.5f
        c.save()
        if (side == 0) c.scale(-1f, 1f, w / 2f, 0f)
        val p = Path()
        p.moveTo(w + 6f, cy - hh); p.lineTo(w, cy - hh)
        p.cubicTo(w, cy - a, w - d, cy - a, w - d, cy)
        p.cubicTo(w - d, cy + a, w, cy + a, w, cy + hh)
        p.lineTo(w + 6f, cy + hh); p.close()
        c.drawPath(p, black); c.drawPath(p, rim)
        c.restore()
    }

    private fun drawPill(c: Canvas, w: Float, h: Float, cy: Float) {
        val sh = show.x.coerceIn(0f, 1f)
        if (sh < 0.01f) { pill.setEmpty(); return }
        val s = dp * scale
        val b = big.x.coerceIn(0f, 1f)
        val pw = (11f + 27f * b) * s
        val ph = (124f + 32f * b) * s
        val left = if (side == 1) w - 30f * dp - pw else 30f * dp
        val top = (cy - ph / 2f).coerceIn(24f * dp, h - ph - 24f * dp)
        pill.set(left, top, left + pw, top + ph)
        val st = stretch.x
        val pivotY = if (st >= 0f) pill.bottom else pill.top
        c.saveLayerAlpha(0f, 0f, w, h, (sh * 255).toInt())
        c.translate((1f - show.x) * 14f * dp * (if (side == 1) 1f else -1f), 0f)
        c.scale(0.6f + 0.4f * show.x, 0.7f + 0.3f * show.x, pill.centerX(), pill.centerY())
        c.scale(1f - abs(st) * 1.2f, 1f + abs(st), pill.centerX(), pivotY)
        val rad = pw / 2f
        c.save()
        c.clipPath(Path().apply { addRoundRect(pill, rad, rad, Path.Direction.CW) })
        c.drawRect(pill, track)
        val fh = ph * disp.coerceIn(0f, 1f)
        c.drawRect(pill.left, pill.bottom - fh, pill.right, pill.bottom, white)
        if (b > 0.3f) drawIcon(c, fh, b)
        c.restore()
        c.restore()
    }

    private fun drawIcon(c: Canvas, fh: Float, b: Float) {
        val col = if (fh > 32f * dp) 0xCC1A1A1E.toInt() else Color.WHITE
        icon.color = col; iconFill.color = col
        icon.alpha = (b * 255).toInt(); iconFill.alpha = (b * 255).toInt()
        c.save()
        c.translate(pill.centerX() - 9f * dp, pill.bottom - 29f * dp)
        c.scale(18f * dp / 24f, 18f * dp / 24f)
        val p = Path()
        p.moveTo(3f, 9f); p.lineTo(3f, 15f); p.lineTo(7f, 15f); p.lineTo(12f, 19f); p.lineTo(12f, 5f); p.lineTo(7f, 9f); p.close()
        c.drawPath(p, iconFill)
        if (disp > 0f) c.drawArc(RectF(7.5f, 7.5f, 16.5f, 16.5f), -45f, 90f, false, icon)
        if (disp > 0.55f) c.drawArc(RectF(4f, 4f, 20f, 20f), -45f, 90f, false, icon)
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val slop = 14f * dp
                val hit = RectF(pill).apply { inset(-slop, -slop) }
                if (pill.width() <= 0f || !hit.contains(e.x, e.y)) return false
                dragging = true; big.t = 1f; onGrab?.invoke(); drag(e.y); kick()
                return true
            }
            MotionEvent.ACTION_MOVE -> if (dragging) { drag(e.y); kick() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false; stretch.t = 0f; onRelease?.invoke(); kick()
            }
        }
        return dragging
    }

    private fun drag(y: Float) {
        val bigH = 156f * dp * scale
        val top = (height * yPct / 100f - bigH / 2f).coerceIn(24f * dp, height - bigH - 24f * dp)
        val rel = (y - top) / bigH
        target = (1f - rel).coerceIn(0f, 1f)
        disp = target
        onVolume?.invoke(target)
        val over = (if (rel < 0f) -rel else if (rel > 1f) rel - 1f else 0f) * bigH / dp
        val e = if (over > 0f) min(0.3f, sqrt(over) / 156f * 2.2f) else 0f
        stretch.x = if (rel < 0f) e else -e
        stretch.v = 0f
    }
}

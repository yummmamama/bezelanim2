package com.example.pixelbezel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** A small, frame-rate-stable spring used by the bezel's shape and rubber-band motion. */
class Spring(
    var x: Float = 0f,
    var t: Float = 0f,
    var k: Float = 420f,
    var c: Float = 19f,
    val eps: Float = 0.15f
) {
    var v = 0f

    fun step(dt: Float) {
        // Several small semi-implicit steps keep the spring consistent across frame rates.
        val count = (dt / 0.008f).toInt().coerceAtLeast(1)
        val h = dt / count
        repeat(count) {
            val acceleration = k * (t - x) - c * v
            v += acceleration * h
            x += v * h
        }
    }

    fun atRest() = abs(v) < eps * 4f && abs(x - t) < eps
}

/** Edge-mounted volume control with an iOS-inspired, bezel-integrated edge shape. */
class BezelView(ctx: Context) : View(ctx) {
    private val dp = resources.displayMetrics.density
    val bubble = Spring(k = 360f, c = 30f, eps = 0.035f) // Distance the bezel expands from the edge.
    val big = Spring(k = 300f, c = 27f, eps = 0.003f)   // 0 = compact, 1 = fully expanded.
    val stretch = Spring(k = 260f, c = 14f, eps = 0.003f)
    var side = 1
    var yPct = 30
    var scale = 1f
    var target = 0.5f
    var dragging = false
        private set
    var onGrab: (() -> Unit)? = null
    var onVolume: ((Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null

    private var disp = 0.5f
    private var last = 0L
    private val hit = RectF()
    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x22FFFFFF
        strokeWidth = 1f
    }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        strokeCap = Paint.Cap.ROUND
    }
    private val iconFill = Paint(Paint.ANTI_ALIAS_FLAG)

    fun kick() = postInvalidateOnAnimation()

    /** Expands from the edge with a slight, controlled spring overshoot. */
    fun open(pressed: Boolean) {
        bubble.k = 360f
        bubble.c = 30f
        bubble.t = 56f
        big.k = 300f
        big.c = 27f
        big.t = 1f
        if (pressed) {
            bubble.v += 62f
            big.v += 0.16f
        }
        kick()
    }

    /** Contracts back into the edge instead of disappearing instantly. */
    fun close() {
        big.t = 0f
        bubble.t = 0f
        bubble.k = 390f
        bubble.c = 33f
        kick()
    }

    private fun cyOf(h: Float): Float {
        val m = 188f * dp * scale
        return (h * yPct / 100f).coerceIn(m, max(m, h - m))
    }

    private fun smoothStep(value: Float): Float {
        val x = value.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.032f, (now - last) / 1e9f)
        last = now

        bubble.step(dt)
        big.step(dt)
        if (!dragging) stretch.step(dt)

        // Exponential smoothing is frame-rate independent and gives volume changes a soft settle.
        val follow = 1f - exp(-dt * 22f)
        disp = if (dragging) target else disp + (target - disp) * follow

        drawEdgeShape(c, width.toFloat(), cyOf(height.toFloat()))

        val busy = dragging || !bubble.atRest() || !big.atRest() || !stretch.atRest() || abs(disp - target) > 0.002f
        if (busy) postInvalidateOnAnimation() else last = 0L
    }

    private fun drawEdgeShape(c: Canvas, w: Float, cy: Float) {
        val s = dp * scale
        val depth = bubble.x.coerceAtLeast(0f) * s
        if (depth < 0.5f) {
            hit.setEmpty()
            return
        }

        // Keep the phone-facing side flush with the display edge. The visible
        // side is one tall, rounded capsule with the slider inset into it.
        val reveal = (depth / (56f * s)).coerceIn(0f, 1f)
        val shape = smoothStep(reveal)
        val halfHeight = (20f + 150f * shape) * s
        fun X(v: Float) = if (side == 1) v else w - v

        val seamX = X(w + 8f * s) // Runs past the display into the physical bezel.
        val innerX = X(w - depth)
        val top = cy - halfHeight
        val bottom = cy + halfHeight
        val rect = RectF(min(seamX, innerX), top, max(seamX, innerX), bottom)
        val corner = min(30f * s, min(depth / 2f, halfHeight * 0.45f))
        // The bezel-facing edge is deliberately straight and extends beyond the
        // display. Only the screen-facing end gets rounded, so the capsule
        // visually grows out of the phone edge without a seam or a curved notch.
        val shapePath = Path().apply {
            if (side == 1) {
                moveTo(seamX, top)
                lineTo(innerX + corner, top)
                quadTo(innerX, top, innerX, top + corner)
                lineTo(innerX, bottom - corner)
                quadTo(innerX, bottom, innerX + corner, bottom)
                lineTo(seamX, bottom)
            } else {
                moveTo(seamX, top)
                lineTo(innerX - corner, top)
                quadTo(innerX, top, innerX, top + corner)
                lineTo(innerX, bottom - corner)
                quadTo(innerX, bottom, innerX - corner, bottom)
                lineTo(seamX, bottom)
            }
            close()
        }
        c.drawPath(shapePath, black)
        // A faint highlight is limited to the rounded, user-facing contour.
        val highlight = Path().apply {
            if (side == 1) {
                moveTo(innerX + corner, top)
                quadTo(innerX, top, innerX, top + corner)
                lineTo(innerX, bottom - corner)
                quadTo(innerX, bottom, innerX + corner, bottom)
            } else {
                moveTo(innerX - corner, top)
                quadTo(innerX, top, innerX, top + corner)
                lineTo(innerX, bottom - corner)
                quadTo(innerX, bottom, innerX - corner, bottom)
            }
        }
        c.drawPath(highlight, rim)

        hit.set(rect)

        // The inner control follows the same spring, appearing a fraction after the outer pill.
        val appear = smoothStep((reveal - 0.10f) / 0.58f)
        if (appear <= 0f) return

        val barWidth = (5f + 29f * shape) * s
        val barHeight = (18f + 250f * shape) * s
        val cx = X(w - depth / 2f)
        val r = RectF(
            cx - barWidth / 2f,
            cy - barHeight / 2f,
            cx + barWidth / 2f,
            cy + barHeight / 2f
        )
        val st = stretch.x
        val pivotY = if (st >= 0f) r.bottom else r.top
        val alpha = (appear * 255f).toInt().coerceIn(0, 255)

        c.save()
        c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), alpha)
        c.scale(1f - abs(st) * 1.2f, 1f + abs(st), r.centerX(), pivotY)
        val sliderRadius = min(barWidth / 2f, 18f * s)
        c.drawRoundRect(r, sliderRadius, sliderRadius, track)
        val fillHeight = barHeight * disp.coerceIn(0f, 1f)
        val fill = RectF(r.left, r.bottom - fillHeight, r.right, r.bottom)
        c.drawRoundRect(fill, sliderRadius, sliderRadius, white)
        if (shape > 0.45f) drawIcon(c, r, fillHeight, shape)
        c.restore()
        c.restore()
    }

    private fun drawIcon(c: Canvas, r: RectF, fillHeight: Float, animation: Float) {
        val s = dp * scale
        val col = if (fillHeight > 32f * s) 0xCC1A1A1E.toInt() else Color.WHITE
        icon.color = col
        iconFill.color = col
        val alpha = (animation * 255f).toInt().coerceIn(0, 255)
        icon.alpha = alpha
        iconFill.alpha = alpha
        c.save()
        c.translate(r.centerX() - 9f * s, r.bottom - 29f * s)
        c.scale(18f * s / 24f, 18f * s / 24f)
        val p = Path().apply {
            moveTo(3f, 9f)
            lineTo(3f, 15f)
            lineTo(7f, 15f)
            lineTo(12f, 19f)
            lineTo(12f, 5f)
            lineTo(7f, 9f)
            close()
        }
        c.drawPath(p, iconFill)
        if (disp > 0f) c.drawArc(RectF(7.5f, 7.5f, 16.5f, 16.5f), -45f, 90f, false, icon)
        if (disp > 0.55f) c.drawArc(RectF(4f, 4f, 20f, 20f), -45f, 90f, false, icon)
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val slop = 12f * dp
                val r = RectF(hit).apply { inset(-slop, -slop) }
                if (hit.width() <= 0f || !r.contains(e.x, e.y)) return false
                dragging = true
                big.t = 1f
                bubble.t = 56f
                bubble.k = 360f
                bubble.c = 30f
                onGrab?.invoke()
                drag(e.y)
                kick()
                return true
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                drag(e.y)
                kick()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false
                stretch.t = 0f
                onRelease?.invoke()
                kick()
            }
        }
        return dragging
    }

    private fun drag(y: Float) {
        val sliderHeight = 268f * dp * scale
        val top = cyOf(height.toFloat()) - sliderHeight / 2f
        val rel = (y - top) / sliderHeight
        target = (1f - rel).coerceIn(0f, 1f)
        disp = target
        onVolume?.invoke(target)

        val over = (if (rel < 0f) -rel else if (rel > 1f) rel - 1f else 0f) * sliderHeight / dp
        val amount = if (over > 0f) min(0.3f, sqrt(over) / 156f * 2.2f) else 0f
        stretch.x = if (rel < 0f) amount else -amount
        stretch.v = 0f
    }
}

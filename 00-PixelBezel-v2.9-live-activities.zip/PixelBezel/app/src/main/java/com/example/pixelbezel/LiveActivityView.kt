package com.example.pixelbezel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Compact Pixel camera-cutout capsule with an expandable live-activity card. */
class LiveActivityView(context: Context) : View(context) {
    private val dp = resources.displayMetrics.density
    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF050507.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = dp; color = 0xFF27272D.toInt()
    }
    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 14f * dp; typeface = android.graphics.Typeface.create("sans-serif-medium", 0)
    }
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFB9BAC3.toInt(); textSize = 12f * dp }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF999AA3.toInt(); textSize = 10f * dp }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFB7C8FF.toInt() }
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFB7C8FF.toInt() }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF373840.toInt() }
    private val panelRect = RectF()
    private var activities: List<LiveActivity> = emptyList()
    private var selected = 0
    private var expanded = false
    private var downX = 0f
    private var downY = 0f
    private var downAt = 0L
    private var lastFrame = 0L
    private val handler = Handler(Looper.getMainLooper())
    private val collapse = Runnable { expanded = false; invalidate() }

    fun setActivities(items: List<LiveActivity>) {
        val oldKey = activities.getOrNull(selected)?.key
        activities = items
        selected = max(0, items.indexOfFirst { it.key == oldKey })
        if (selected >= items.size) selected = 0
        if (items.isEmpty()) expanded = false
        invalidate()
    }

    fun hasActivities() = activities.isNotEmpty()

    fun cycle() {
        if (activities.size > 1) selected = (selected + 1) % activities.size
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val item = activities.getOrNull(selected) ?: return
        val now = SystemClock.uptimeMillis()
        val pulse = 0.80f + 0.20f * (0.5f + 0.5f * kotlin.math.sin(now / 420.0)).toFloat()
        val cx = width / 2f
        val cardW = min(width - 12f * dp, 352f * dp)
        val cardH = if (expanded) min(height - 8f * dp, 170f * dp) else 50f * dp
        val top = 4f * dp
        panelRect.set(cx - cardW / 2f, top, cx + cardW / 2f, top + cardH)
        canvas.drawRoundRect(panelRect, if (expanded) 28f * dp else 28f * dp, 28f * dp, panel)
        canvas.drawRoundRect(panelRect, 28f * dp, 28f * dp, stroke)

        if (!expanded) {
            item.icon?.let { drawIcon(canvas, it, panelRect.left + 14f * dp, panelRect.centerY() - 10f * dp, 20f * dp) }
            accentPaint.alpha = (255 * pulse).toInt()
            canvas.drawCircle(panelRect.left + 48f * dp, panelRect.centerY(), 3f * dp, accentPaint)
            val label = if (item.kind == ActivityKind.MEDIA) item.title else "${item.kind.label} · ${item.title}"
            drawEllipsized(canvas, label, panelRect.left + 59f * dp, panelRect.centerY() + 5f * dp,
                panelRect.width() - 104f * dp, titlePaint)
            item.icon?.let { drawIcon(canvas, it, panelRect.right - 31f * dp, panelRect.centerY() - 8f * dp, 16f * dp) }
        } else {
            item.icon?.let { drawIcon(canvas, it, panelRect.left + 18f * dp, panelRect.top + 16f * dp, 24f * dp) }
            smallPaint.color = 0xFF9698A2.toInt()
            canvas.drawText("${item.appName} · ${item.kind.label}", panelRect.left + 51f * dp,
                panelRect.top + 27f * dp, smallPaint)
            if (activities.size > 1) {
                val count = "${selected + 1}/${activities.size}  ›"
                canvas.drawText(count, panelRect.right - 47f * dp, panelRect.top + 27f * dp, smallPaint)
            }
            drawEllipsized(canvas, item.title, panelRect.left + 18f * dp,
                panelRect.top + 64f * dp, panelRect.width() - 36f * dp, titlePaint)
            val info = buildString {
                if (item.text.isNotBlank() && item.text != item.title) append(item.text)
                if (item.chronometer && item.whenMillis > 0) {
                    if (isNotEmpty()) append("  ·  ")
                    append(formatElapsed(item))
                } else if (item.progressMax > 0) {
                    if (isNotEmpty()) append("  ·  ")
                    append("${(100L * item.progress / item.progressMax).coerceIn(0, 100)}%")
                }
            }
            if (info.isNotBlank()) drawEllipsized(canvas, info, panelRect.left + 18f * dp,
                panelRect.top + 87f * dp, panelRect.width() - 36f * dp, bodyPaint)
            if (item.progressMax > 0) {
                val bar = RectF(panelRect.left + 18f * dp, panelRect.top + 100f * dp,
                    panelRect.right - 18f * dp, panelRect.top + 104f * dp)
                canvas.drawRoundRect(bar, 2f * dp, 2f * dp, trackPaint)
                bar.right = bar.left + bar.width() * (item.progress.toFloat() / item.progressMax).coerceIn(0f, 1f)
                canvas.drawRoundRect(bar, 2f * dp, 2f * dp, progressPaint)
            }
            drawActions(canvas, item)
        }
        if (item.chronometer && !item.countDown && !expanded || expanded && item.chronometer) postInvalidateDelayed(1000)
        else if (activities.isNotEmpty()) postInvalidateDelayed(650)
    }

    private fun drawActions(canvas: Canvas, item: LiveActivity) {
        val actions = item.actions.take(3)
        if (actions.isEmpty()) return
        val gap = 6f * dp
        val left = panelRect.left + 14f * dp
        val top = panelRect.bottom - 42f * dp
        val totalW = panelRect.width() - 28f * dp
        val chipW = (totalW - gap * (actions.size - 1)) / actions.size
        actions.forEachIndexed { i, action ->
            val r = RectF(left + i * (chipW + gap), top, left + i * (chipW + gap) + chipW, top + 28f * dp)
            accentPaint.alpha = 30
            canvas.drawRoundRect(r, 14f * dp, 14f * dp, accentPaint)
            smallPaint.color = 0xFFE5E6ED.toInt()
            smallPaint.textAlign = Paint.Align.CENTER
            drawEllipsized(canvas, action.title, r.centerX(), r.centerY() + 4f * dp, r.width() - 10f * dp, smallPaint, true)
            smallPaint.textAlign = Paint.Align.LEFT
        }
    }

    private fun drawIcon(canvas: Canvas, icon: android.graphics.drawable.Drawable, left: Float, top: Float, size: Float) {
        canvas.save()
        icon.setBounds(left.toInt(), top.toInt(), (left + size).toInt(), (top + size).toInt())
        icon.alpha = 255
        icon.draw(canvas)
        canvas.restore()
    }

    private fun drawEllipsized(c: Canvas, source: String, x: Float, baseline: Float, maxWidth: Float, paint: Paint, centered: Boolean = false) {
        var value = source.replace('\n', ' ').trim()
        if (paint.measureText(value) > maxWidth) {
            while (value.isNotEmpty() && paint.measureText("$value…") > maxWidth) value = value.dropLast(1)
            value += "…"
        }
        c.drawText(value, if (centered) x else x, baseline, paint)
    }

    private fun formatElapsed(item: LiveActivity): String {
        val now = System.currentTimeMillis()
        val elapsed = if (item.countDown) (item.whenMillis - now).coerceAtLeast(0L) else (now - item.whenMillis).coerceAtLeast(0L)
        val sec = elapsed / 1000
        return "%d:%02d".format(sec / 60, sec % 60)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (activities.isEmpty()) return false
        val card = panelRect
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!card.contains(event.x, event.y)) return false
                downX = event.x; downY = event.y; downAt = SystemClock.uptimeMillis()
                return true
            }
            MotionEvent.ACTION_UP -> {
                val elapsed = SystemClock.uptimeMillis() - downAt
                val moved = kotlin.math.hypot(event.x - downX, event.y - downY) > 18f * dp
                if (!moved && elapsed > 550 && activities.size > 1) cycle()
                else if (!moved && expanded && event.y > panelRect.bottom - 48f * dp) {
                    val item = activities.getOrNull(selected)
                    val actions = item?.actions.orEmpty().take(3)
                    if (actions.isNotEmpty()) {
                        val gap = 6f * dp
                        val left = panelRect.left + 14f * dp
                        val chipW = (panelRect.width() - 28f * dp - gap * (actions.size - 1)) / actions.size
                        val index = ((event.x - left) / (chipW + gap)).toInt().coerceIn(0, actions.lastIndex)
                        try { actions[index].pendingIntent.send() } catch (_: Exception) {}
                    }
                } else if (!moved && !expanded) {
                    expanded = true
                    handler.removeCallbacks(collapse)
                    handler.postDelayed(collapse, 10000)
                }
                else if (!moved && expanded && event.x > panelRect.right - 58f * dp && event.y < panelRect.top + 42f * dp) cycle()
                else if (!moved && expanded) {
                    try { activities.getOrNull(selected)?.contentIntent?.send() } catch (_: Exception) {}
                }
                else if (moved && kotlin.math.abs(event.x - downX) > 44f * dp) {
                    if (event.x < downX) cycle() else expanded = false
                }
                if (moved && kotlin.math.abs(event.x - downX) > 44f * dp && event.x > downX) {
                    handler.removeCallbacks(collapse)
                }
                performClick()
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
